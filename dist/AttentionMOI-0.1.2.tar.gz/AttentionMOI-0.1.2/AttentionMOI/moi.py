def run_main():
    from AttentionMOI.deepmoi import main
    main()
